//
//  ViewController.h
//  UIseachController
//
//  Created by liaozhi on 16/7/4.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

