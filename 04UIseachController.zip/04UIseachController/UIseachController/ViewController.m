//
//  ViewController.m
//  UIseachController
//
//  Created by liaozhi on 16/7/4.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchResultsUpdating>
@property (nonatomic,weak)IBOutlet UITableView *table;
@property (nonatomic,strong)UISearchController *searchController;
@property (nonatomic,strong)NSMutableArray *List;
@property (nonatomic,strong)NSMutableArray *searchList;
@property (nonatomic,strong)NSMutableArray *indexList;
@end

@implementation ViewController
- (NSMutableArray *)List {
    if (!_List) {
        _List = [NSMutableArray arrayWithObjects:@"a",@"b",@"c",@"d",@"e",@"f",@"g",@"h",nil];
    }
    return _List;
}
- (NSMutableArray *)searchList {
    if (!_searchList) {
        _searchList = [[NSMutableArray alloc] init];
    }
    return _searchList;
}
- (UISearchController *)searchController {
    if (!_searchController) {
        _searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
        _searchController.searchBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 44);
        _searchController.searchResultsUpdater = self;
        _searchController.searchBar.delegate = self;
        _searchController.dimsBackgroundDuringPresentation = NO;
        _searchController.hidesNavigationBarDuringPresentation = YES;
        //设置searchBar的背景颜色
        UIView *backV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
        backV.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        [_searchController.searchBar insertSubview:backV atIndex:1];
        //或者设置背景图
//        _searchController.searchBar.backgroundImage = [UIImage imageNamed:@"man"];
    }
    return _searchController;
}
#pragma - mark 增加手势点击编辑区域以外的区域，取消UISeachBar的键盘
- (void)resignJianPan {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)viewTapped:(UITapGestureRecognizer *)tap {
    if (self.searchController.active) {
        [self.searchController.searchBar resignFirstResponder];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.table.tableHeaderView = self.searchController.searchBar;
    self.table.sectionIndexBackgroundColor = [UIColor clearColor];
    self.table.separatorInset = UIEdgeInsetsZero;//分割线一直延伸到左边,如果不设置该项则达不到微信中分割线的效果
    self.table.dataSource = self;
    self.table.delegate = self;
    [self resignJianPan];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (self.searchController.active) {
        self.searchController.active = NO;
        [self.searchController.searchBar removeFromSuperview];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
#pragma -mark UISearchBarDelegate(设置右侧按钮属性)
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    searchBar.showsCancelButton = YES;
    for (UIView *btn in [[searchBar.subviews lastObject] subviews]) {
        if ([btn isKindOfClass:[UIButton class]]) {
            UIButton *b = (UIButton *)btn;
            [b setTitle:@"取消" forState:UIControlStateNormal];
        }
    }
}
#pragma -mark UISearchResultsUpdating
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController {
    if (self.searchList.count != 0) {
        [self.searchList removeAllObjects];
    }
    for (NSString *string in self.List) {
        NSRange range = [string rangeOfString:self.searchController.searchBar.text];
        if (range.location != NSNotFound) {
            [self.searchList addObject:string];
        }
    }
    [self.table reloadData];
}

#pragma -mark UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.searchController.active) {
        return self.searchList.count;
    }else {
    return self.List.count;
    }
}
//如果定义了ViewForHeader该方法，则这个方法不会被调用
//- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
//    if (self.searchController.active) {
//        return self.searchList[section];
//        NSLog(@"%@",self.searchList[section]);
//    }else{
//        return self.List[section];
//    }
//}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"test";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    cell.imageView.image = [UIImage imageNamed:@"women"];
    cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    return cell;
}
//索引
- (NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    self.indexList = [NSMutableArray arrayWithArray:self.List];
    [self.indexList insertObject:UITableViewIndexSearch atIndex:0];
    return self.indexList;
}
- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    if ([title isEqualToString:UITableViewIndexSearch])
    {
        [tableView setContentOffset:CGPointZero animated:YES];//当按到搜索符号时，tabview移至顶部
        return NSNotFound;
    }
    else
    {
        return index-1; // -1 由于添加了搜索标识，所以其他标识位置-1
    }
}
#pragma -mark UITableViewDelegate
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *v = [[UIView alloc] init];
    v.backgroundColor = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, tableView.frame.size.width, 22)];
    label.textColor = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1];
    if (self.searchController.active) {
        label.text = self.searchList[section];
        [v addSubview:label];
        return v;
    }else{
        label.text = self.List[section];
        [v addSubview:label];
        return v;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSLog(@"123");
}

@end
